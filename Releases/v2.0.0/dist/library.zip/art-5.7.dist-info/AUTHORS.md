# Core Developer #

----------
- Sepand Haghighi - Sharif University of Technology - [@sepandhaghighi](http://github.com/sepandhaghighi)
- Sadra Sabouri - Sharif University of Technology - [@sadrasabouri](https://github.com/sadrasabouri)

# Other Contributors #
----------
- [@heidecjj](https://github.com/heidecjj)
- [@noobkoder](https://github.com/n00bkoder)
